MQTTnet.TestApp.WinForm
====================================

MQTTnet.TestApp.WinForm is a test application to test [MQTTnet](https://github.com/chkr1011/MQTTnet).
The assembly was written and tested in .Net 5.0 and originally created by [@grammyleung](https://github.com/grammyleung).

[![Build status](https://ci.appveyor.com/api/projects/status/pbwhpsm7er0yaw5r?svg=true)](https://ci.appveyor.com/project/SeppPenner/mqttnet-testapp-winform)
[![GitHub issues](https://img.shields.io/github/issues/SeppPenner/MQTTnet.TestApp.WinForm.svg)](https://github.com/SeppPenner/MQTTnet.TestApp.WinForm/issues)
[![GitHub forks](https://img.shields.io/github/forks/SeppPenner/MQTTnet.TestApp.WinForm.svg)](https://github.com/SeppPenner/MQTTnet.TestApp.WinForm/network)
[![GitHub stars](https://img.shields.io/github/stars/SeppPenner/MQTTnet.TestApp.WinForm.svg)](https://github.com/SeppPenner/MQTTnet.TestApp.WinForm/stargazers)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://raw.githubusercontent.com/SeppPenner/MQTTnet.TestApp.WinForm/master/License.txt)
[![Known Vulnerabilities](https://snyk.io/test/github/SeppPenner/MQTTnet.TestApp.WinForm/badge.svg)](https://snyk.io/test/github/SeppPenner/MQTTnet.TestApp.WinForm)

Change history
--------------

See the [Changelog](https://github.com/SeppPenner/MQTTnet.TestApp.WinForm/blob/master/Changelog.md).