# Change history

* **Version 1.0.1.0 (2020-12-27)** : Removed license year, moved changelog to extra file, adjusted folder structure, updated nuget packages, moved to Net 5.0.
* **Version 1.0.0.0 (2020-01-15)** : 1.0 release.