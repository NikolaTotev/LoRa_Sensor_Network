#include "Gas_Sensor_Test.h" //Examples

int main()
{
	Gas_Sensor_test(); //Dynamic Measurement
}
