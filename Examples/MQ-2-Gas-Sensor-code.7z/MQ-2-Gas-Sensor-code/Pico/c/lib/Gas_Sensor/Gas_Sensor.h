#ifndef __Gas_Sensor_H
#define __Gas_Sensor_H

#include "DEV_Config.h"
#include <stdlib.h>
void Gas_Sensor();

#endif
