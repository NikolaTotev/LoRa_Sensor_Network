﻿namespace Mqtt.Client.AspNetCore.Settings
{
    public class AppSettingsProvider
    {
        public static BrokerHostSettings BrokerHostSettings;
        public static ClientSettings ClientSettings;
    }
}
