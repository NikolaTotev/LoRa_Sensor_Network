﻿namespace Mqtt.Client.AspNetCore.Settings
{
    public class BrokerHostSettings
    {
        public string Host { set; get; }
        public int Port { set; get; }
    }
}
