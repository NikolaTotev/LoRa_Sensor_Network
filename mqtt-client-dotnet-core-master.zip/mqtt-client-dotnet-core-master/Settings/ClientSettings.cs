﻿namespace Mqtt.Client.AspNetCore.Settings
{
    public class ClientSettings
    {
        public string Id { set; get; }
        public string UserName { set; get; }
        public string Password { set; get; }
    }
}
